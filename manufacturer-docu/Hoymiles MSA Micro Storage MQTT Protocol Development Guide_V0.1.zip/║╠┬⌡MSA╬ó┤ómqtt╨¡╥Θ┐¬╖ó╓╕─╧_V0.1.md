# 禾迈MSA微储MQTT协议开发指南

### 1、基本配置信息（设备发布）
*备注: 设备连接后立刻发布，用于设备发现*

**topic:**
`homeassistant/switch/<dev_id>/config`

**payload:**
```json
{
  "state_topic": "homeassistant/sensor/<dev_id>/device/state",
  "command_topic": "homeassistant/switch/<dev_id>/set",
  "json_attributes_topic": "homeassistant/sensor/<dev_id>/attributes",
  "unique_id": "<dev_id>",
  "device": {
    "identifiers": ["<id>"],         
    "name": "<dev_id>",              
    "manufacturer": "Hoymiles",              
    "model": "MS-A2",
    "sw_version": "1.0.0"    
  }
}
```

**qos:**
`1`

**retain:**
`true`

### 2、基本属性信息（设备发布）
*备注: 设备连接后立刻发布，用于主题同步*

**topic:**
`homeassistant/sensor/<dev_id>/attributes`

**payload:**
```json
{
  "supported_topics": {
    "quick_state": "homeassistant/sensor/<dev_id>/quick/state",
    "device_state": "homeassistant/sensor/<dev_id>/device/state",
    "system_state": "homeassistant/sensor/<dev_id>/system/state",
    "switch_ctrl": "homeassistant/switch/<dev_id>/set",
    "ems_mode": "homeassistant/select/<dev_id>/ems_mode/command",
    "power_ctrl": "homeassistant/number/<dev_id>/power_ctrl/set" 
  }
}
```

**qos:**
`1`

**retain:**
`true`

**note:**  
`supported_topics`: 表示设备支持发布和订阅的主题  
`quick_state`: 设备发布的主题，用于设备自身及系统状态的快速更新，详见第10章节  
`device_state`: 设备发布的主题，用于设备自身状态的定时更新，详见第11章节  
`system_state`: 设备发布的主题，用于系统状态的定时更新，详见第12章节  
`switch_ctrl`: 设备响应的主题，用于设备开关机控制，详见第7章节  
`ems_mode`: 设备响应的主题，用于设置EMS模式，详见第8章节  
`power_ctrl`: 设备响应的主题，用于控制功率，详见第9章节  

### 3、EMS模式配置（设备发布）
*备注: 设备连接后立刻发布，用于通知功率控制规则，此主题仅主机和单机支持*

**topic:**
`homeassistant/select/<dev_id>/ems_mode/config`

**payload:**
```json
{
  "command_topic": "homeassistant/select/<dev_id>/ems_mode/command",
  "options": ["general", "mqtt_ctrl"],
  "unique_id": "<dev_id>",
  "device": {
    "identifiers": ["<id>"],         
    "name": "<dev_id>",              
    "manufacturer": "Hoymiles",              
    "model": "MS-A2"  
  }
}
```

**qos:**
`1`

**retain:**
`true`

**note:**  
`options`: 系统EMS模式(`general`: 默认，启用后设备通过固有逻辑进行能量管理， `mqtt_ctrl`: 启用后设备响应mqtt指令控制功率，可以通过`homeassistant/number/<dev_id>/power_ctrl/set`主题进行能量管理)  

### 4、功率控制配置（设备发布）
*备注: 设备连接后立刻发布，用于通知功率控制规则，此主题仅主机和单机支持*

**topic:**
`homeassistant/number/<dev_id>/power_ctrl/config`

**payload:**
```json
{
  "name": null,
  "command_topic": "homeassistant/number/<dev_id>/power_ctrl/set",
  "device_class": "power",
  "unit_of_measurement": "w",
  "min": -1000,
  "max": 1000,
  "step": 0.1,
  "unique_id": "<dev_id>",
  "device": {
    "identifiers": ["<id>"],         
    "name": "<dev_id>",              
    "manufacturer": "Hoymiles",              
    "model": "MS-A2"  
  }
}
```

**qos:**
`1`

**retain:**
`true`


### 5、电量信息展示配置（设备发布）
*备注: 设备连接后立刻发布，用于电量展示信息配置*

**topic:**
`homeassistant/sensor/<dev_id>/soc/config`

**payload:**
```json
{
  "name": "soc",       
  "state_topic": "homeassistant/sensor/<dev_id>/quick/state",  
  "value_template": "{{ value_json.soc }}",
  "device_class": "battery",
  "unit_of_measurement": "%",
  "device": {
    "identifiers": ["<id>"],         
    "name": "<dev_id>",              
    "manufacturer": "Hoymiles",              
    "model": "MS-A2"  
  }
}
```

**qos:**
`1`

**retain:**
`true`

### 6、电池充放电功率展示配置（设备发布）
*备注: 设备连接后立刻发布，用于功率展示信息配置*

**topic:**
`homeassistant/sensor/<dev_id>/bat_p/config`

**payload:**
```json
{
  "name": "bat_power",       
  "state_topic": "homeassistant/sensor/<dev_id>/quick/state",  
  "value_template": "{{ value_json.bat_p }}",
  "device_class": "power",
  "unit_of_measurement": "W",
  "device": {
    "identifiers": ["<id>"],         
    "name": "<dev_id>",              
    "manufacturer": "Hoymiles",              
    "model": "MS-A2"  
  }
}
```

**qos:**
`1`

**retain:**
`true`

### 7、开关机控制（设备订阅）[预留功能]
*备注: 设备订阅并响应，暂不支持*

**topic:**
`homeassistant/switch/<dev_id>/set`

**payload:**
`ON`

**qos:**
`1`

**retain:**
`false`

**note:**  
`payload`中可设置类型包括`ON`和`OFF`。

### 8、EMS模式（设备订阅）
*备注: 设备订阅并响应，此主题仅主机和单机支持*

**topic:**
`homeassistant/select/<dev_id>/ems_mode/command`

**payload:**
`mqtt_ctrl`

**qos:**
`1`

**retain:**
`false`

**note:**  
`payload`中可设置类型见`homeassistant/select/<dev_id>/ems_mode/config`主题中的`options`。

### 9、功率控制（设备订阅）
*备注: 设备订阅并响应，此主题仅主机和单机支持*

**topic:**
`homeassistant/number/<dev_id>/power_ctrl/set`

**payload:**
`80.0`

**qos:**
`1`

**retain:**
`false`

**note:**  
`payload`中可设置范围见`homeassistant/number/<dev_id>/power_ctrl/config`主题中的`min`和`max`。

### 10、秒级数据（设备发布）
*备注: 设备间隔1秒发布，包含设备及系统*

**topic:**
`homeassistant/sensor/<dev_id>/quick/state`

**payload:**
```json
{
    "grid_on_p": 0.1,
    "grid_off_p": 0.1,
    "bat_sts": "standby",
    "bat_p": 0.1,
    "soc": 0.01,

    "sys_pv_p": 0.1,
    "sys_plug_p": 0.1,
    "sys_bat_p": 0.1,
    "sys_grid_p": 0.1,
    "sys_load_p": 0.1,
    "sys_sp_p": 0.1,
    "sys_soc": 0.01
}
```

**qos:**
`0`

**retain:**
`false`

**note:**  
`grid_on_p`: 设备并网口有功功率(最小单位: 0.1W)  
`grid_off_p`: 设备离网口有功功率(最小单位: 0.1W)  
`bat_sts`: 设备电池状态(`standby`: 待机, `charge`: 充电, `discharge`: 放电, `lock`: 锁定)  
`bat_p`: 设备电池功率(最小单位: 0.1W)  
`soc`: 设备剩余电量(最小单位: 0.01%)  
`sys_pv_p`: 系统光伏功率(最小单位: 0.1W)  
`sys_plug_p`: 系统插座功率(最小单位: 0.1W)  
`sys_bat_p`: 系统电池功率(最小单位: 0.1W)  
`sys_grid_p`: 系统电网功率(最小单位: 0.1W)  
`sys_load_p`: 系统负载功率(最小单位: 0.1W)  
`sys_sp_p`: 系统智能插座功率(最小单位: 0.1W)  
`sys_soc`: 系统电池电量(最小单位: 0.01%)  

### 11、设备实时数据（设备发布）
*备注: 设备间隔5分钟发布*

**topic:**
`homeassistant/sensor/<dev_id>/device/state`

**payload:**
```json
{
    "grid":[
    {
        "type": "grid_on",
        "v": 0.1,
        "i": 0.01,
        "f": 0.01,
        "p": 0.1,
        "q": 0.1,
        "ein": 1,
        "eout": 1,
        "etin": 1,
        "etout": 1
    },
    {
        "type": "grid_off",
        "v": 0.1,
        "i": 0.01,
        "f": 0.01,
        "p": 0.1,
        "q": 0.1,
        "ein": 1,
        "eout": 1,
        "etin": 1,
        "etout": 1
    },
    {
        "type": "inv",
        "v": 0.1,
        "i": 0.01,
        "p": 0.1,
        "q": 0.1,
        "ein": 1,
        "eout": 1,
        "etin": 1,
        "etout": 1
    }],

    "bat_sts": "standby",
    "bat_v": 0.01,
    "bat_i": 0.01,
    "bat_p": 0.1,
    "bat_temp": 0.1,

    "soc": 0.01,
    "rssi": -10

}
```

**qos:**
`1`

**retain:**
`false`

**note:**  
`type`: 设备端口类型(`grid_on`: 并网口, `grid_off`: 离网口, `inv`: 逆变口)  
`v`: 设备端口电压(最小单位: 0.1V)  
`i`: 设备端口电流(最小单位: 0.01A)  
`f`: 设备端口频率(最小单位: 0.01Hz)  
`p`: 设备端口有功功率(最小单位: 0.1W)  
`q`: 设备端口无功功率(最小单位: 0.1VAR)  
`ein`: 设备端口当日输入电量(最小单位: 1Wh)  
`eout`: 设备端口当日输出电量(最小单位: 1Wh)  
`etin`: 设备端口历史累计输入电量(最小单位: 1Wh)  
`etout`: 设备端口历史累计输出电量(最小单位: 1Wh)  
`bat_sts`: 设备电池状态(`standby`: 待机, `charge`: 充电, `discharge`: 放电, `lock`: 锁定)  
`bat_v`: 设备电池电压(最小单位: 0.01V)  
`bat_i`: 设备电池电流(最小单位: 0.01A)  
`bat_p`: 设备电池功率(最小单位: 0.1W)  
`bat_temp`: 设备电池温度(最小单位: 0.1℃)  
`soc`: 设备剩余电量(最小单位: 0.01%)  
`rssi`: 设备信号值(最小单位: 1dBm)  

### 12、系统实时数据（设备发布）
*备注: 设备间隔5分钟发布，此主题仅主机和单机支持*

**topic:**
`homeassistant/sensor/<dev_id>/system/state`

**payload:**
```json
{
    "pv_p": 0.1,
    "plug_p": 0.1,
    "bat_p": 0.1,
    "grid_p": 0.1,
    "load_p": 0.1,
    "sp_p": 0.1,
    "soc": 0.01,

    "pv_e": 1,
    "dchg_e": 1,
    "chg_e": 1,
    "plug_out_e": 1,
    "plug_in_e": 1,
    
    "ems_mode": "general"

}
```

**qos:**
`1`

**retain:**
`false`

**note:**  
`pv_p`: 系统光伏功率(最小单位: 0.1W)  
`plug_p`: 系统插座功率(最小单位: 0.1W)  
`bat_p`: 系统电池功率(最小单位: 0.1W)  
`grid_p`: 系统电网功率(最小单位: 0.1W)  
`load_p`: 系统负载功率(最小单位: 0.1W)  
`sp_p`: 系统智能插座功率(最小单位: 0.1W)  
`soc`: 系统电池电量(最小单位: 0.01%)  
`pv_e`: 系统当日光伏发电量(最小单位: 1Wh)  
`dchg_e`: 系统当日电池侧放电量(最小单位: 1Wh)  
`chg_e`: 系统当日电池侧充电量(最小单位: 1Wh)  
`plug_out_e`: 系统当日并网插座输出电量(最小单位: 1Wh)  
`plug_in_e`: 系统当日并网插座输入电量(最小单位: 1Wh)  
`ems_mode`: 系统当前运行的EMS模式(`general`: 设备自身控制功率, `mqtt_ctrl`: mqtt指令控制功率)  
